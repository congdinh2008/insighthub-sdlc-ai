# Các phép kiểm ngoài JSON Schema

Phiên bản 0.2 | 23/09/2026 | Kế hoạch kiểm theo SRS v1.0 | Chưa chạy trên sản phẩm

Các ca dưới cụ thể hóa điều kiện đã có trong SRS, không tạo bài tập/điểm chấm mới. Cột lớp kiểm xác định nơi chứng minh; ví dụ JSON đúng hình dạng không chứng minh các ca này đạt.

| Mã | Tình huống | Kết quả bắt buộc | Lớp kiểm và truy vết |
| --- | --- | --- | --- |
| DC-01 | Owner gửi Notebook của mình với child ID của người khác | Cùng phản hồi công khai như không tìm thấy, không dữ liệu hoặc hiệu ứng | API/quyền; IH-NB-004, IH-NFR-002 |
| DC-02 | Request tự khai owner, score, trạng thái hoặc schema version không có trong input contract | Từ chối; không ghi giá trị server từ client | Schema + API; IH-DATA-001 |
| DC-03 | Update bằng phiên bản cũ | 409, bản hiện hành giữ nguyên; đọc lại nếu còn quyền | Lưu trữ; BR-12 |
| DC-04 | Mật khẩu confirmation khác; khoảng trắng/Unicode khác | So khớp nguyên chuỗi; không normalize mật khẩu | Auth; IH-AUTH-001/007/010 |
| DC-05 | PendingVerification đọc Notebook/API trực tiếp | Không truy cập nghiệp vụ; vẫn dùng được quyền xác minh giới hạn và reset công khai | Auth; IH-AUTH-002, UC-02.A4 |
| DC-06 | Google cùng email, chưa xác nhận mật khẩu hoặc bằng chứng sai giao dịch/hết 5 phút/đã dùng | Không liên kết/cấp quyền; giữ dữ liệu cũ | Auth; IH-AUTH-005, LIM-19 |
| DC-07 | Login thành công xen giữa các lần sai trong cửa sổ | Không xóa bộ đếm lần sai còn hiệu lực; chặn đúng thời điểm LIM-09 | Auth/rate limit; IH-AUTH-003-AC02 |
| DC-08 | Hết idle/absolute, polling liên tục, đổi/reset mật khẩu hoặc restart | Không kéo dài bằng polling; thu hồi/hết hạn còn hiệu lực sau restart | Auth/persistence; IH-AUTH-008, LIM-07 |
| DC-09 | Hai yêu cầu AI mới đồng thời từ cùng owner | Chỉ tiếp nhận trong một suất dùng chung chat/năm tool; operation/target nhất quán | Concurrency; LIM-10, IH-INT-004 |
| DC-10 | Replay cùng key sau thêm nguồn hoặc đổi model/default | Cùng target và snapshot cũ; không tiêu quota mới | API/persistence; SRS 3.3.2 |
| DC-11 | Nguồn đổi thứ tự, ID lặp, bỏ nguồn và gửi [] | Đổi thứ tự cùng nghĩa; ID lặp/[] lỗi; bỏ nguồn RAG chỉ resolve lần đầu | Canonical input; IH-DATA-001, IH-INT-004 |
| DC-12 | Cùng key khác Notebook/question/config; cùng key khác owner | Cùng owner khác input: 409; khác owner không mở target cũ | API; BR-10, IH-NFR-002 |
| DC-13 | Operation hết TTL, mở lại business resource | Dữ liệu nghiệp vụ còn theo chính sách riêng; không xóa theo TTL | Persistence; IH-NFR-004, LIM-12 |
| DC-14 | Restart ngay trước/sau deadline, provider trả muộn | Không reset deadline; không publish sau thời hạn; giải phóng suất đúng trạng thái | Runtime; IH-NFR-005/007 |
| DC-15 | Xóa nguồn commit trước publish | Tác vụ Failed, không Artifact/answer thành công dù đã giữ đoạn nguồn trong bộ nhớ | Transaction; BR-08 |
| DC-16 | Publish trước xóa nguồn | Giữ nội dung đã lưu; mọi citation/snapshot view loại excerpt và locator nguồn, đánh dấu Unavailable | API/lưu trữ; BR-08, SRS 3.7.5 |
| DC-17 | Response tới sau khi client đã biết nguồn/Notebook bị xóa hoặc đổi phiên | Đối soát hiện hành; không đưa dữ liệu phiên cũ/đã xóa trở lại; Notebook bị xóa không có lịch sử truy cập được | API/UI đồng thời; BR-08/09 |
| DC-18 | Job Succeeded bị replay đồng thời; sau đó xóa Artifact và replay | Ban đầu đúng một Artifact; sau xóa không tái tạo hoặc phục vụ payload từ operation | Lưu trữ; IH-AI-003, IH-INT-004 |
| DC-19 | Retry ingestion cũ trả muộn; tệp trùng byte/khác byte cùng tên | Chỉ attempt hiện hành publish; byte trùng áp BR-04, tên trùng không thay hash | Ingestion; IH-DOC-002/003/004 |
| DC-20 | Nguồn sai owner/Notebook/chưa Ready, locator không thuộc tài liệu hoặc ngoài tập đã nhận | Từ chối trước sử dụng/công bố; không dùng chỉ tên tệp để khớp | Domain/quyền; BR-07, IH-AI-004 |
| DC-21 | Mindmap 10-30 nút nhưng trùng ID, hai gốc, vòng lặp, cha thiếu hoặc độ sâu 1/5 | Output invalid; chỉ chấp nhận một cây nối đầy đủ, sâu 2-4; nhánh chính có citation | Domain; IH-MM-001, LIM-17 |
| DC-22 | Summary ngắn/chi tiết ở dưới, đúng và trên giới hạn từ | Theo đúng bộ đếm từ SRS: 150-250 hoặc 400-600; không tính danh sách citation | Domain/content; IH-SUM-001, LIM-17 |
| DC-23 | Slides đủ 5-8 nhưng khác số đã chọn, trang đầu/cuối sai hoặc nhiều title/conclusion | Invalid; đúng số cấu hình, đúng một title đầu và conclusion cuối; mỗi content có 3-5 ý | Domain; IH-SLD-001 |
| DC-24 | Quiz đủ 5/10 nhưng sai số đã chọn, trùng question/option ID hoặc nội dung lựa chọn, đáp án không thuộc options | Invalid; ID duy nhất đúng phạm vi, bốn lựa chọn phân biệt, một đáp án hợp lệ | Domain; IH-QUIZ-001 |
| DC-25 | Quiz đúng schema nhưng đáp án sai/mơ hồ hoặc giải thích không có căn cứ | Không đạt oracle/AEV; JSON hợp lệ không chứng minh đúng nội dung | Corpus/người đánh giá; AEV-05, BR-13 |
| DC-26 | Trước nộp, đọc Artifact/rename/list/poll/export/error/log | Không answer key/explanation/score của lần chưa nộp; chỉ submitted attempt được trả review | API projection; IH-QUIZ-002, IH-DATA-002 |
| DC-27 | Submit câu/option ngoài đề, bỏ câu, nộp đồng thời hoặc nộp lại với lựa chọn khác | Lần đầu kiểm ID, bỏ câu tính sai; chấm/lưu một lần, replay trả kết quả cũ theo BR-14 | Domain/transaction; IH-DATA-002 |
| DC-28 | Score có tổng câu/đáp án đúng không nhất quán hoặc làm tròn sai | Server tính lại từ đề bất biến và lựa chọn, 1 chữ số thập phân | Domain; BR-14 |
| DC-29 | Report 599/600/1000/1001 từ; goal/source khác request; export thay nội dung | Biên 600..1000; đúng mục tiêu/nguồn, phân biệt fact/inference/proposal; export đúng bản lưu | Domain/content; IH-RPT-001/002 |
| DC-30 | Thiếu/rỗng title; title hợp lệ dài 121; đổi display_name rồi mở lại | Thiếu/rỗng invalid; dài hợp lệ dùng tên hiển thị fallback; đổi tên không đổi content.title | Schema + persistence; SRS 3.7.9 |
| DC-31 | Output tự khai tool/version/owner hoặc dữ liệu lưu có version chưa hỗ trợ | Server chọn envelope; mismatch rejected; reader báo lỗi an toàn và giữ dữ liệu | Contract/version; SRS 3.7.9 |
| DC-32 | Phát hành schema mới khi còn Artifact cũ | Inventory phiên bản thực tế; có reader/migration và kiểm bảo toàn trước rollout; không tái sinh AI thay lịch sử | Migration/restore; IH-NFR-004/009 |
| DC-33 | Xóa Artifact gốc khi regenerate đã được nhận; xóa Note/Conversation độc lập | Bản mới có thể tiếp tục nếu nguồn/Notebook hợp lệ; bản sao Note giữ nội dung theo SRS | Lifecycle; SRS 3.7.5 |
| DC-34 | Cursor đổi owner/Notebook/filter; nhiều phần tử trùng thời điểm | Từ chối cursor sai ngữ cảnh; tie-break ID ổn định; duyệt đủ khi dữ liệu không đổi | API pagination; SRS 3.7.3 |
| DC-35 | Tệp/nguồn tại biên và vượt LIM-03/04/05, PDF ảnh/mã hóa, MIME giả | Máy chủ kiểm nội dung, số trang, dung lượng/ký tự; không cắt ngầm hoặc chỉ tin MIME | Ingestion/domain; IH-DOC-001, IH-DATA-001 |
| DC-36 | Provider/validator hỏng nhưng hệ thống trả NoEvidence | Không đạt; lỗi kỹ thuật phải Failed, sửa trong deadline hoặc dừng | Runtime; IH-CHAT-003, IH-AI-003 |
| DC-37 | Email lỗi sau đổi mật khẩu/linking đã commit | Giữ kết quả và thu hồi phiên; ghi/chuyển giao lại email theo chính sách, không bắt làm lại nghiệp vụ | Auth/email; IH-MSG-003 |

Mỗi ca khi thực hiện phải ghi candidate, cấu hình/provider, input, expected, actual, kết luận và link evidence. Đánh giá nội dung toàn R1 vẫn theo 18 lượt AEV và ngoại lệ trong SRS; danh sách trên không thay corpus/oracle hoặc các AC còn lại.
