"""Validate documentation only. Does not call or verify InsightHub runtime."""
from pathlib import Path
import json
import hashlib
import importlib.metadata
from jsonschema import Draft202012Validator, FormatChecker
from openapi_spec_validator import validate_spec

base = Path(__file__).resolve().parent
schema = json.loads((base / "schemas.json").read_text())
api = json.loads((base / "openapi.json").read_text())
examples = json.loads((base / "examples.json").read_text())
checks = []

def check(name, passed, detail=""):
    checks.append({"name": name, "passed": bool(passed), "detail": detail})

try:
    Draft202012Validator.check_schema(schema)
    check("JSON Schema 2020-12 document", True)
except Exception as exc:
    check("JSON Schema 2020-12 document", False, str(exc))

try:
    validate_spec(api)
    check("OpenAPI 3.1 document", True)
except Exception as exc:
    check("OpenAPI 3.1 document", False, str(exc))

def convert_refs(value):
    if isinstance(value, dict):
        return {k: (v.replace("#/$defs/", "#/components/schemas/")
                    if k == "$ref" else convert_refs(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [convert_refs(v) for v in value]
    return value

check("Standalone and OpenAPI schema definitions agree",
      convert_refs(schema["$defs"]) == api["components"]["schemas"])
operation_ids = [op["operationId"] for item in api["paths"].values() for op in item.values()]
check("Unique operation IDs", len(set(operation_ids)) == len(operation_ids))
public_responses = [response for item in api["paths"].values()
                    for op in item.values() for response in op["responses"].values()]
check("Internal envelope not a direct response",
      "InternalAIOutput" not in json.dumps(public_responses))
results = []
for case in examples["cases"]:
    target = {"$schema": schema["$schema"], "$defs": schema["$defs"],
              "$ref": "#/$defs/" + case["schema"]}
    errors = list(Draft202012Validator(target, format_checker=FormatChecker()).iter_errors(case["data"]))
    actual = not errors
    results.append({"id": case["id"], "description": case["description"],
                    "schema": case["schema"], "expected_valid": case["expected_valid"],
                    "actual_valid": actual, "passed": actual == case["expected_valid"]})

result = {
    "scope": "Static contract and synthetic schema cases only; no product, provider, concurrency, domain or AI quality tests executed.",
    "tools": {name: importlib.metadata.version(name) for name in ["jsonschema", "openapi-spec-validator"]},
    "input_sha256": {name: hashlib.sha256((base / name).read_bytes()).hexdigest()
                     for name in ["schemas.json", "openapi.json", "examples.json", "schema_support.json"]},
    "schema_definitions": len(schema["$defs"]), "operations": len(operation_ids),
    "structural_checks": checks, "cases": results,
    "passed": all(x["passed"] for x in checks + results),
}
(base / "validation_result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"passed": result["passed"], "structural_checks": len(checks),
                  "schema_cases": len(results), "failures": [x for x in checks + results if not x["passed"]]}, ensure_ascii=False))
raise SystemExit(0 if result["passed"] else 1)
