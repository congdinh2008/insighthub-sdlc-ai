# Mapping giao tiếp R1 tới SRS

Đường dẫn và tên trường là thiết kế Draft v0.2. Mã dưới xác định yêu cầu chi phối và tập AC cần phân tích khi kiểm thao tác; không có nghĩa một thao tác API tự đáp ứng mọi AC được dẫn. Quy tắc dùng chung trong SRS và các ca domain vẫn áp dụng. Bảng không là kết quả kiểm thử.

| Phương thức | Đường dẫn | Thao tác | Yêu cầu | AC đối chiếu |
| --- | --- | --- | --- | --- |
| GET | `/auth/csrf` | `getCsrf` | IH-NFR-011 | IH-NFR-011-AC01, IH-NFR-011-AC02 |
| POST | `/auth/register` | `register` | IH-AUTH-001, IH-AUTH-002 | IH-AUTH-001-AC01, IH-AUTH-001-AC02, IH-AUTH-002-AC01, IH-AUTH-002-AC02 |
| POST | `/auth/login` | `login` | IH-AUTH-003, IH-AUTH-008 | IH-AUTH-003-AC01, IH-AUTH-003-AC02, IH-AUTH-008-AC01, IH-AUTH-008-AC02 |
| POST | `/auth/verification/consume` | `verifyEmail` | IH-AUTH-002 | IH-AUTH-002-AC01, IH-AUTH-002-AC02 |
| POST | `/auth/verification/resend` | `resendVerification` | IH-AUTH-002, IH-MSG-003 | IH-AUTH-002-AC01, IH-AUTH-002-AC02, IH-MSG-003-AC01, IH-MSG-003-AC02, IH-MSG-003-AC03 |
| POST | `/auth/password/request` | `requestPasswordReset` | IH-AUTH-006 | IH-AUTH-006-AC01, IH-AUTH-006-AC02 |
| POST | `/auth/password/reset` | `resetPassword` | IH-AUTH-007, IH-AUTH-008 | IH-AUTH-007-AC01, IH-AUTH-007-AC02, IH-AUTH-007-AC03, IH-AUTH-008-AC01, IH-AUTH-008-AC02 |
| POST | `/auth/password/change` | `changePassword` | IH-AUTH-010, IH-AUTH-008 | IH-AUTH-008-AC01, IH-AUTH-008-AC02, IH-AUTH-010-AC01, IH-AUTH-010-AC02 |
| POST | `/auth/google/link` | `linkGoogle` | IH-AUTH-005 | IH-AUTH-005-AC01, IH-AUTH-005-AC02, IH-AUTH-005-AC03, IH-AUTH-005-AC04 |
| POST | `/auth/logout` | `logout` | IH-AUTH-008 | IH-AUTH-008-AC01, IH-AUTH-008-AC02 |
| GET | `/auth/verification` | `getVerification` | IH-AUTH-002 | IH-AUTH-002-AC01, IH-AUTH-002-AC02 |
| GET | `/auth/google/start` | `startGoogle` | IH-AUTH-004 | IH-AUTH-004-AC01, IH-AUTH-004-AC02 |
| GET | `/auth/google/callback` | `googleCallback` | IH-AUTH-004, IH-AUTH-005 | IH-AUTH-004-AC01, IH-AUTH-004-AC02, IH-AUTH-005-AC01, IH-AUTH-005-AC02, IH-AUTH-005-AC03, IH-AUTH-005-AC04 |
| GET | `/me` | `getProfile` | IH-AUTH-009 | IH-AUTH-009-AC01, IH-AUTH-009-AC02 |
| PATCH | `/me` | `updateProfile` | IH-AUTH-009 | IH-AUTH-009-AC01, IH-AUTH-009-AC02 |
| GET | `/notebooks` | `listNotebooks` | IH-NB-001 | IH-NB-001-AC01, IH-NB-001-AC02 |
| POST | `/notebooks` | `createNotebook` | IH-NB-001 | IH-NB-001-AC01, IH-NB-001-AC02 |
| GET | `/notebooks/{notebook_id}` | `getNotebook` | IH-NB-002 | IH-NB-002-AC01, IH-NB-002-AC02 |
| PATCH | `/notebooks/{notebook_id}` | `updateNotebook` | IH-NB-002 | IH-NB-002-AC01, IH-NB-002-AC02 |
| DELETE | `/notebooks/{notebook_id}` | `deleteNotebook` | IH-NB-003 | IH-NB-003-AC01, IH-NB-003-AC02 |
| GET | `/notebooks/{notebook_id}/conversations` | `listConversation` | IH-CHAT-004 | IH-CHAT-004-AC01, IH-CHAT-004-AC02, IH-CHAT-004-AC03, IH-CHAT-004-AC04, IH-CHAT-004-AC05 |
| POST | `/notebooks/{notebook_id}/conversations` | `createConversation` | IH-CHAT-004 | IH-CHAT-004-AC01, IH-CHAT-004-AC02, IH-CHAT-004-AC03, IH-CHAT-004-AC04, IH-CHAT-004-AC05 |
| GET | `/notebooks/{notebook_id}/conversations/{resource_id}` | `getConversation` | IH-CHAT-004 | IH-CHAT-004-AC01, IH-CHAT-004-AC02, IH-CHAT-004-AC03, IH-CHAT-004-AC04, IH-CHAT-004-AC05 |
| PATCH | `/notebooks/{notebook_id}/conversations/{resource_id}` | `updateConversation` | IH-CHAT-004 | IH-CHAT-004-AC01, IH-CHAT-004-AC02, IH-CHAT-004-AC03, IH-CHAT-004-AC04, IH-CHAT-004-AC05 |
| DELETE | `/notebooks/{notebook_id}/conversations/{resource_id}` | `deleteConversation` | IH-CHAT-004 | IH-CHAT-004-AC01, IH-CHAT-004-AC02, IH-CHAT-004-AC03, IH-CHAT-004-AC04, IH-CHAT-004-AC05 |
| GET | `/notebooks/{notebook_id}/notes` | `listNote` | IH-NOTE-001 | IH-NOTE-001-AC01, IH-NOTE-001-AC02, IH-NOTE-001-AC03, IH-NOTE-001-AC04 |
| POST | `/notebooks/{notebook_id}/notes` | `createNote` | IH-NOTE-001, IH-NOTE-002, IH-SUM-002 | IH-NOTE-001-AC01, IH-NOTE-001-AC02, IH-NOTE-001-AC03, IH-NOTE-001-AC04, IH-NOTE-002-AC01, IH-NOTE-002-AC02, IH-SUM-002-AC01, IH-SUM-002-AC02 |
| GET | `/notebooks/{notebook_id}/notes/{resource_id}` | `getNote` | IH-NOTE-001 | IH-NOTE-001-AC01, IH-NOTE-001-AC02, IH-NOTE-001-AC03, IH-NOTE-001-AC04 |
| PATCH | `/notebooks/{notebook_id}/notes/{resource_id}` | `updateNote` | IH-NOTE-001 | IH-NOTE-001-AC01, IH-NOTE-001-AC02, IH-NOTE-001-AC03, IH-NOTE-001-AC04 |
| DELETE | `/notebooks/{notebook_id}/notes/{resource_id}` | `deleteNote` | IH-NOTE-001 | IH-NOTE-001-AC01, IH-NOTE-001-AC02, IH-NOTE-001-AC03, IH-NOTE-001-AC04 |
| GET | `/notebooks/{notebook_id}/documents` | `listDocuments` | IH-DOC-003 | IH-DOC-003-AC01, IH-DOC-003-AC02 |
| POST | `/notebooks/{notebook_id}/documents` | `uploadDocument` | IH-DOC-001, IH-DOC-002, IH-DOC-004, IH-INT-004 | IH-INT-004-AC01, IH-INT-004-AC02, IH-DOC-001-AC01, IH-DOC-001-AC02, IH-DOC-002-AC01, IH-DOC-002-AC02, IH-DOC-004-AC01, IH-DOC-004-AC02 |
| GET | `/notebooks/{notebook_id}/documents/{document_id}` | `getDocument` | IH-DOC-003 | IH-DOC-003-AC01, IH-DOC-003-AC02 |
| DELETE | `/notebooks/{notebook_id}/documents/{document_id}` | `deleteDocument` | IH-DOC-006 | IH-DOC-006-AC01, IH-DOC-006-AC02 |
| GET | `/notebooks/{notebook_id}/documents/{document_id}/text` | `getDocumentText` | IH-DOC-005 | IH-DOC-005-AC01, IH-DOC-005-AC02 |
| POST | `/notebooks/{notebook_id}/documents/{document_id}/retry` | `retryDocument` | IH-DOC-003, IH-INT-004 | IH-INT-004-AC01, IH-INT-004-AC02, IH-DOC-003-AC01, IH-DOC-003-AC02 |
| GET | `/notebooks/{notebook_id}/ingestion-attempts/{attempt_id}` | `getIngestionAttempt` | IH-DOC-003, IH-MSG-004 | IH-DOC-003-AC01, IH-DOC-003-AC02, IH-MSG-004-AC01, IH-MSG-004-AC02 |
| GET | `/notebooks/{notebook_id}/conversations/{conversation_id}/turns` | `listChatTurns` | IH-CHAT-004 | IH-CHAT-004-AC01, IH-CHAT-004-AC02, IH-CHAT-004-AC03, IH-CHAT-004-AC04, IH-CHAT-004-AC05 |
| POST | `/notebooks/{notebook_id}/conversations/{conversation_id}/turns` | `createChatTurn` | IH-CHAT-001, IH-INT-004 | IH-INT-004-AC01, IH-INT-004-AC02, IH-CHAT-001-AC01, IH-CHAT-001-AC02 |
| GET | `/notebooks/{notebook_id}/conversations/{conversation_id}/turns/{turn_id}` | `getChatTurn` | IH-CHAT-002, IH-CHAT-003 | IH-CHAT-002-AC01, IH-CHAT-002-AC02, IH-CHAT-003-AC01, IH-CHAT-003-AC02 |
| POST | `/notebooks/{notebook_id}/conversations/{conversation_id}/turns/{turn_id}/retry` | `retryChatTurn` | IH-CHAT-005, IH-INT-004 | IH-INT-004-AC01, IH-INT-004-AC02, IH-CHAT-005-AC01, IH-CHAT-005-AC02 |
| POST | `/notebooks/{notebook_id}/generation-jobs` | `createGeneration` | IH-AI-001, IH-AI-002, IH-AI-003, IH-MM-001, IH-SUM-001, IH-SLD-001, IH-QUIZ-001, IH-RPT-001, IH-INT-004 | IH-INT-004-AC01, IH-INT-004-AC02, IH-AI-001-AC01, IH-AI-001-AC02, IH-AI-002-AC01, IH-AI-002-AC02, IH-AI-003-AC01, IH-AI-003-AC02, IH-MM-001-AC01, IH-MM-001-AC02, IH-SUM-001-AC01, IH-SUM-001-AC02, IH-SLD-001-AC01, IH-SLD-001-AC02, IH-QUIZ-001-AC01, IH-QUIZ-001-AC02, IH-RPT-001-AC01, IH-RPT-001-AC02 |
| GET | `/notebooks/{notebook_id}/generation-jobs/{job_id}` | `getGenerationJob` | IH-MSG-004 | IH-MSG-004-AC01, IH-MSG-004-AC02 |
| POST | `/notebooks/{notebook_id}/generation-jobs/{job_id}/retry` | `retryGeneration` | IH-INT-004 | IH-INT-004-AC01, IH-INT-004-AC02 |
| GET | `/notebooks/{notebook_id}/artifacts` | `listArtifacts` | IH-OUT-001 | IH-OUT-001-AC01, IH-OUT-001-AC02 |
| GET | `/notebooks/{notebook_id}/artifacts/{artifact_id}` | `getArtifact` | IH-OUT-001, IH-DATA-001 | IH-OUT-001-AC01, IH-OUT-001-AC02, IH-DATA-001-AC01, IH-DATA-001-AC02, IH-DATA-001-AC03, IH-DATA-001-AC04, IH-DATA-001-AC05, IH-DATA-001-AC06 |
| PATCH | `/notebooks/{notebook_id}/artifacts/{artifact_id}` | `renameArtifact` | IH-OUT-002 | IH-OUT-002-AC01, IH-OUT-002-AC02 |
| DELETE | `/notebooks/{notebook_id}/artifacts/{artifact_id}` | `deleteArtifact` | IH-OUT-003 | IH-OUT-003-AC01, IH-OUT-003-AC02 |
| POST | `/notebooks/{notebook_id}/artifacts/{artifact_id}/regenerate` | `regenerateArtifact` | IH-OUT-002, IH-INT-004 | IH-INT-004-AC01, IH-INT-004-AC02, IH-OUT-002-AC01, IH-OUT-002-AC02 |
| GET | `/notebooks/{notebook_id}/artifacts/{artifact_id}/report.md` | `downloadReport` | IH-RPT-002 | IH-RPT-002-AC01, IH-RPT-002-AC02 |
| GET | `/notebooks/{notebook_id}/artifacts/{artifact_id}/quiz-attempts` | `listQuizAttempts` | IH-DATA-002 | IH-DATA-002-AC01, IH-DATA-002-AC02, IH-DATA-002-AC03, IH-DATA-002-AC04 |
| POST | `/notebooks/{notebook_id}/artifacts/{artifact_id}/quiz-attempts` | `startQuizAttempt` | IH-QUIZ-002, IH-DATA-002 | IH-QUIZ-002-AC01, IH-QUIZ-002-AC02, IH-DATA-002-AC01, IH-DATA-002-AC02, IH-DATA-002-AC03, IH-DATA-002-AC04 |
| GET | `/notebooks/{notebook_id}/artifacts/{artifact_id}/quiz-attempts/{attempt_id}` | `getQuizAttempt` | IH-DATA-002 | IH-DATA-002-AC01, IH-DATA-002-AC02, IH-DATA-002-AC03, IH-DATA-002-AC04 |
| POST | `/notebooks/{notebook_id}/artifacts/{artifact_id}/quiz-attempts/{attempt_id}/submit` | `submitQuizAttempt` | IH-QUIZ-002, IH-DATA-002 | IH-QUIZ-002-AC01, IH-QUIZ-002-AC02, IH-DATA-002-AC01, IH-DATA-002-AC02, IH-DATA-002-AC03, IH-DATA-002-AC04 |
| GET | `/operations/{operation_id}` | `getOperation` | IH-INT-004 | IH-INT-004-AC01, IH-INT-004-AC02 |
| GET | `/operations/lookup` | `lookupOperation` | IH-INT-004 | IH-INT-004-AC01, IH-INT-004-AC02 |
| GET | `/notebooks/{notebook_id}/documents/{document_id}/source` | `getCitationSource` | IH-DOC-005, IH-AI-004, IH-CHAT-002 | IH-DOC-005-AC01, IH-DOC-005-AC02, IH-CHAT-002-AC01, IH-CHAT-002-AC02, IH-AI-004-AC01, IH-AI-004-AC02 |
