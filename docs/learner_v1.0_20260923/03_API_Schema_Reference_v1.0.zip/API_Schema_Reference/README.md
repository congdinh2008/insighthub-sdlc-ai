# Hợp đồng giao tiếp InsightHub R1

Phiên bản 0.2 Draft | 23/09/2026 | Thiết kế để review | Tham chiếu REF-05 của SRS v1.0

Bộ này cụ thể hóa giao tiếp HTTP và cấu trúc dữ liệu cho toàn sản phẩm R1, gồm Mindmap, Tóm tắt, Slide, Quiz và Báo cáo. [SRS v1.0](../02_SRS_InsightHub_v1.0.md) là nguồn hành vi. Các đường dẫn, tên JSON, cơ chế cookie và phân trang dưới đây là lựa chọn thiết kế của bản Draft này; kết quả triển khai và kiểm provider được quản lý trong hồ sơ nghiệm thu.

| Tệp | Mục đích |
| --- | --- |
| [openapi.json](openapi.json) | Giao tiếp HTTP: request, response, lỗi, quyền, phân trang và thao tác bất đồng bộ |
| [schemas.json](schemas.json) | Nguồn định nghĩa JSON Schema; gồm view công khai, nội bộ và năm cấu trúc nội dung |
| [schema_support.json](schema_support.json) | Danh mục cặp công cụ/phiên bản được thiết kế hỗ trợ |
| [API_Mapping.md](API_Mapping.md) | Tra thao tác API về mã yêu cầu SRS |
| [examples.json](examples.json) | Test case hợp lệ/không hợp lệ để kiểm cấu trúc; dữ liệu mô phỏng |
| [Domain_Checks.md](Domain_Checks.md) | Quy tắc và test case nghiệp vụ, quyền, vòng đời ngoài khả năng JSON Schema |
| [validate_contract.py](validate_contract.py) | Kiểm cấu trúc OpenAPI, Schema, đồng bộ định nghĩa và ví dụ |
| [requirements-contract.txt](requirements-contract.txt) | Phiên bản công cụ kiểm tài liệu |
| [validation_result.json](validation_result.json) | Kết quả kiểm tĩnh và giới hạn kết luận |

## 1. Quyết định biểu diễn và ranh giới

- Dùng [OpenAPI 3.1.1](https://spec.openapis.org/oas/v3.1.1.html) và [JSON Schema 2020-12](https://json-schema.org/draft/2020-12). Đây là định dạng được chọn để tương thích công cụ kiểm, không phải tuyên bố phiên bản mới nhất hoặc yêu cầu của ISO. Các keyword `required` và `additionalProperties` có nghĩa theo [JSON Schema](https://json-schema.org/understanding-json-schema/reference/object).
- API có tiền tố `/api/r1`; endpoint và tên trường có thể thay qua quyết định thiết kế nếu giữ hành vi SRS và cập nhật đồng bộ contract/test trước tích hợp. Không có bảng DB, framework hoặc provider xác thực bắt buộc từ bộ này.
- `schemas.json/$defs` là nguồn của schema. `openapi.json/components/schemas` chứa bản chuyển tham chiếu tương đương để tài liệu OpenAPI đọc độc lập. Công cụ kiểm phát hiện lệch giữa hai bản; không sửa một bản riêng rồi coi contract đã đồng bộ.
- Token công cụ là `Mindmap`, `Summary`, `Slides`, `Quiz`, `Report`; nhãn UI tương ứng là Mindmap, Tóm tắt, Slide, Quiz, Báo cáo. Phiên bản cấu trúc nội dung đầu tiên được thiết kế là `1.0` cho từng loại; phiên bản gói contract là `0.2.0-draft`. Hai loại phiên bản có mục đích khác nhau.
- ID là chuỗi opaque 1-128 ký tự. Thời điểm phản hồi dùng RFC 3339 UTC kết thúc bằng `Z`. ID/giờ/trạng thái/owner được server cấp; miền giá trị cụ thể của ID là thiết kế, không thêm hạn mức sản phẩm.
- Object không nhận trường ngoài contract; thiếu, `null`, rỗng và sai kiểu là các trường hợp khác nhau. `null` chỉ được dùng cho cha của nút gốc Mindmap. Dùng JSON boolean/number đúng kiểu, không nhận chuỗi thay số. JSON Schema áp dụng sau chuẩn hóa đầu vào theo SRS; mật khẩu giữ nguyên.

## 2. Phiên và luồng tài khoản

Thiết kế chọn phiên phía server và cookie `ih_session`, `HttpOnly`, `Secure`, `SameSite=Lax`; môi trường dùng HTTPS local/sandbox. Cookie chỉ là phương tiện tham chiếu phiên, không mang quyền do client tự khai. Các mốc 2 giờ không hoạt động, 24 giờ tuyệt đối và thu hồi tối đa 60 giây vẫn do server/provider thực thi theo LIM-07. Polling không gia hạn phiên. HTTP header `Cache-Control: no-store` áp dụng cho dữ liệu xác thực, tài nguyên riêng tư và phản hồi lỗi liên quan.

Mọi thao tác thay đổi trạng thái qua API JSON phải kiểm `Origin` với origin triển khai cho phép và `X-CSRF-Token` ràng buộc phiên hoặc ngữ cảnh trước đăng nhập. `/auth/csrf` cấp token cho ngữ cảnh đó, không cấp token xác minh email. Google callback là ngoại lệ về header vì là điều hướng từ provider: phải kiểm giao dịch `state`, `nonce`, issuer, audience, thời hạn và email đã xác minh. Hủy/lỗi callback không tạo phiên. Callback có đúng một trong `code` hoặc `error`, luôn có `state` hợp lệ; schema tham số HTTP không thay kiểm kết hợp này.

Profile tenant, URL callback đăng ký, provider/thư viện/phiên bản và bằng chứng khả thi thuộc REF-07. Không chốt các giá trị môi trường chưa được cung cấp. `/auth/google/start` chỉ tạo URL tới provider đã cấu hình với callback cho phép; không nhận redirect URL tùy ý từ client. Giao dịch liên kết có thời hạn theo LIM-19 và bị ràng buộc với bằng chứng Google đã kiểm, tài khoản và mục đích. `link_transaction_id` không thay xác minh mật khẩu hiện tại. Với tài khoản chờ xác minh đã có mật khẩu, phải hoàn tất UC-02.A4 rồi bắt đầu lại Google và xác nhận mật khẩu mới; không liên kết chỉ từ email trùng.

Đăng nhập tài khoản chờ xác minh trả phạm vi `VerificationOnly`; chỉ cho đọc trạng thái xác minh, gửi lại email và đăng xuất. API nghiệp vụ đòi tài khoản `Active`; thao tác khôi phục công khai vẫn được dùng. Phản hồi xác minh thành công chỉ xác nhận trạng thái và hướng dẫn đăng nhập, không tự cấp quyền bằng callback do client tự khai. Hồ sơ User và trạng thái xác minh là hai view riêng.

Đăng ký đã tồn tại, yêu cầu khôi phục với email không có hoặc không đủ điều kiện vẫn dùng phản hồi công khai không phân biệt theo SRS. Phản hồi khôi phục chỉ xác nhận đã tiếp nhận, không trả “email không tồn tại”. Với giới hạn gắn tài khoản, hành vi công khai không được biến thành kênh phát hiện tài khoản; giới hạn IP có thể trả `429` cùng quy tắc cho mọi email. Password confirmation phải so khớp chính xác; JSON Schema kiểm hình dạng nhưng không thay phép so hai trường.

## 3. Quy tắc trao đổi dữ liệu

### 3.1. Tạo/sửa, phân trang và lỗi

Mọi sửa metadata gửi `expected_version`; server so phiên bản hiện hành và trả `409 Conflict` khi cũ. Không tự ghi đè. Khi dữ liệu thay đổi làm thay phiên bản đang dùng cho kiểm xung đột thì server tăng phiên bản tương ứng; việc polling không làm thay đổi nó. Xóa không cần trả nội dung (`204`) sau commit xóa logic. Xóa lặp tài nguyên đã xóa thuộc chính người dùng có cùng kết quả; không dùng quy tắc này để tiết lộ ID thuộc người khác.

Phân trang dùng `cursor` opaque, `limit` mặc định 20, khoảng 1-100. `next_cursor` chỉ có khi còn trang tiếp theo, không dùng `null`. Cursor bị ràng buộc owner, danh sách cha, bộ lọc và thứ tự; sửa cursor hoặc dùng chéo ngữ cảnh trả `400`, không mở quyền. Thứ tự giảm dần theo mốc SRS quy định, rồi ID giảm dần khi trùng thời điểm. Với dữ liệu không đổi, duyệt hết không bỏ sót/lặp mục. Danh sách đang thay đổi được đọc theo trạng thái hiện hành; giao diện loại lặp theo ID và cho làm mới từ đầu, không cam kết snapshot xuyên nhiều request.

| HTTP | Ý nghĩa thiết kế |
| --- | --- |
| 200 / 201 | Đọc/cập nhật thành công hoặc tạo tài nguyên nghiệp vụ |
| 202 | Đã ghi nhận thao tác và target bền vững; chưa có nghĩa xử lý thành công |
| 204 | Xóa logic hoàn tất, không body |
| 400 | Sai cấu trúc, giá trị, callback hoặc tổ hợp tham số |
| 401 | Thiếu/hết phiên hoặc xác thực thất bại; mã lỗi phân biệt trường hợp an toàn |
| 403 | Phiên hạn chế hoặc kiểm CSRF/Origin không đạt; không dùng để phân biệt quyền trên tài nguyên người khác |
| 404 | Tài nguyên không tồn tại/không thuộc quyền/không còn truy cập được; cùng cấu trúc công khai |
| 409 | Phiên bản cũ, cùng key khác nội dung, trạng thái không cho thao tác hoặc nguồn không còn hợp lệ |
| 413 | Tệp vượt giới hạn dung lượng |
| 429 | Hạn mức cửa sổ hoặc suất AI dùng chung; có `Retry-After` và `retry_after_seconds` nhất quán |
| 500 / 503 | Lỗi server hoặc phụ thuộc; thông điệp an toàn, có mã tra cứu, không stack trace/token |

`NoEvidence` trả trong trạng thái ChatTurn/GenerationJob, không là lỗi HTTP. Đọc tác vụ thất bại vẫn là đọc thành công (`200`) với `status=Failed`; lỗi transport và lỗi xử lý nghiệp vụ không bị trộn. `UnsupportedSchemaVersion` dùng `409` khi đọc nội dung lưu mà reader không hỗ trợ; giữ dữ liệu và chặn hiển thị. Trường lỗi theo tên trường dùng mã ổn định, không để frontend phân tích thông điệp tiếng Việt.

### 3.2. Thao tác, mặc định và đối soát

`Idempotency-Key` bắt buộc với ingestion, chat, generation, retry và regenerate. Key chỉ dùng cho một hành động logic, không chứa dữ liệu nhạy cảm. Server ghi operation và target nhất quán trước trả `202`. `target.type` phân biệt IngestionAttempt, ChatTurn và GenerationJob; trạng thái Operation phải khớp target, ngoại trừ `Deleted` khi chỉ còn dấu đã xóa an toàn. Trả lại cùng yêu cầu đã nhận dùng cùng cấu trúc `Accepted`, cùng operation/target, trạng thái hiện tại.

Thứ tự xử lý: kiểm phiên/quyền cơ bản; chuẩn hóa input và tra key; nếu có thì so input với default của lần đầu, kiểm quyền/trạng thái hiện tại và trả lại hoặc báo xung đột; chỉ nếu chưa có mới resolve default, nguồn và profile, kiểm hạn mức rồi tiếp nhận nhất quán. Không tính quota trước bước phát hiện replay.

- Trim/NFC các trường theo SRS, giữ mật khẩu nguyên chuỗi. Body ghi chú/văn bản không tự trim mất ngắt dòng. Không đổi câu hỏi để bỏ nội dung có nghĩa.
- Nguồn là tập ID duy nhất, sắp xếp khi tạo fingerprint; ID lặp là lỗi. Không gửi nguồn RAG nghĩa là tập `Ready` tại lần đầu; `[]` là lỗi. Dấu “không chỉ định nguồn” được lưu riêng để phân biệt với danh sách cụ thể.
- Default: Notebook.description=`""`; Conversation.title=`"Hội thoại mới"`; instructions=`""`; Summary.length=`short`; Slides.slide_count=5; Quiz.question_count=5. Topic Slide và goal Report luôn bắt buộc. Khi đọc Artifact, config phản ánh toàn bộ giá trị đã resolve, không bỏ các default đã áp dụng.
- Replay input bỏ tùy chọn và input gửi rõ đúng default đã lưu là tương đương. Thay default/model/nguồn hiện hành không đổi tác vụ cũ. Multipart ingestion so byte hash và metadata đã nhận; không coi tên tệp giống là byte giống.
- Retry sau lỗi tạo operation mới và quan hệ `previous_attempt_id`; không cho retry tác vụ đang chạy hoặc đã thành công. Regenerate từ Artifact dùng cấu hình/nguồn của bản gốc, kiểm lại ở thời điểm nhận mới, tạo Artifact độc lập và quan hệ `regenerated_from_id`.
- Thời hạn key tối thiểu 24 giờ không xóa business resource. Khi key không còn tra được, server trả `404`; client tra business resource và đối soát trước hành động mới, không tự cấp key mới chỉ vì mất kết nối. Tác vụ hết deadline sau restart phải kết thúc phù hợp, không khởi động lại đồng hồ.

### 3.3. Đầu ra năm công cụ và Quiz

Provider trả phần `content`; `InternalAIOutput` là cấu trúc kiểm nội bộ sau khi server gắn `tool_type` và `schema_version` từ cấu hình đã nhận. Adapter provider không được nhận envelope tự khai của mô hình làm nguồn tin cậy. Trước publish phải kiểm schema và các luật trong Domain_Checks, nguồn/quyền/deadline. Không có endpoint trả thẳng `InternalAIOutput`.

`Artifact` luôn công bố Quiz dưới `QuizPublicContent`: chỉ tiêu đề, câu hỏi và lựa chọn. Đáp án, giải thích, điểm chỉ có qua `QuizAttemptSubmitted` của người có quyền sau nộp. API đổi tên, danh sách, polling, lỗi, export và log đều không được mở đường đọc answer key. Điểm của lần đã nộp vẫn được xem; lần mới không kế thừa trạng thái “đã nộp”. Người dùng có thể đọc lại lời giải của lần cũ theo SRS, không có cam kết ngăn họ ghi nhớ đáp án.

Nộp bài gửi object ánh xạ question ID -> option ID; câu bỏ trống không xuất hiện trong object. Không nhận score, correct answer hoặc question lạ. Máy chủ lưu lựa chọn, điểm, thời điểm và `Submitted` nguyên tử. Nộp lặp trả bản đã lưu, không chấm lại; làm lại tạo ID mới. Không có endpoint lưu nháp từng lựa chọn.

`content.title` bắt buộc không rỗng và bất biến; `display_name` tối đa 120 ký tự, đổi được. Tiêu đề hợp lệ dài hơn 120 ký tự không làm sai nội dung; server đặt `display_name` bằng nhãn công cụ và thời điểm. Thiếu tiêu đề phải sửa output trong deadline hoặc `Failed`. Đổi tên tăng `metadata_version`, không đổi `schema_version` hoặc `content.title`.

Citation hiện hành của nguồn khả dụng có locator; khi nguồn đã xóa, view chỉ giữ ID, tên và `Unavailable`, không có locator/excerpt. Kiểm publish yêu cầu các nguồn vẫn hợp lệ; đọc lịch sử cho phép view đã loại dữ liệu nguồn theo BR-08. Phải xử lý nhất quán cả nguồn trong nội dung lồng nhau, snapshot, cache, operation và phản hồi muộn.

## 4. Kiểm chứng và điều kiện tích hợp

Chạy `validate_contract.py` trong môi trường Python có hai gói của `requirements-contract.txt`. Công cụ không gọi API sản phẩm, model, Google hoặc email. Ví dụ là dữ liệu mô phỏng để kiểm hình dạng; nội dung ngắn minh họa trong ví dụ không được dùng làm bằng chứng AEV hoặc số từ đã đạt.

Kiểm tĩnh xác nhận: tài liệu OpenAPI hợp lệ theo validator; mọi schema đúng cú pháp; định nghĩa ở hai file đồng bộ; các ví dụ có verdict cấu trúc như đã khai. Các domain test case trong [Domain_Checks.md](Domain_Checks.md) cần được chuyển thành kiểm trên implementation/candidate và corpus tương ứng; không đánh dấu Pass từ kết quả kiểm tĩnh.

Trước tích hợp, kỹ thuật/QA review các lựa chọn cookie/CSRF, endpoint, cursor, adapter và schema version; ghi quyết định chọn contract. Trước nghiệm thu, có contract test trên candidate, profile tenant/provider thực, các test case về đồng thời/xóa/restart, corpus toàn năm tool và migration nếu có dữ liệu phiên bản trước. [Danh mục hồ sơ nghiệm thu trong SRS](../02_SRS_InsightHub_v1.0.md#sec-4-4-4) xác định bằng chứng cần hoàn tất.
